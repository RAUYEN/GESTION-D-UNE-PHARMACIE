﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacie.Properties
{
    public partial class pharmaSearch : Form
    {
        public pharmaSearch()
        {
            InitializeComponent();
        }

        private void pharmaSearch_Load(object sender, EventArgs e)
        {
            // appel db -> select * medica where pharmaName = x
            // update list
        }


        private void tbMedicament_TextChanged(object sender, EventArgs e)
        {
            
            // si medica existe:
            this.lblResult.ForeColor = Color.Green;
            this.lblResult.Text = "Oui, disponible.\nPrix: " + 50.ToString() + "dt.";
            this.btnBuy.Enabled = true;

            // si tb vide

            if (tbMedicament.Text == "")
            {
                lblResult.Text = "";
                btnBuy.Enabled = false;
            }
            // sinon si medica existe dans une autre pharma

            if (tbMedicament.Text == "sokra")
            {

                this.lblResult.ForeColor = Color.GreenYellow;
                this.lblResult.Text = "Oui, disponible @pharmacie x.\nPrix: " + 50.ToString() + "dt.";
                this.btnBuy.Enabled = false;
            }

            // sinon non dispo
            if (tbMedicament.Text == "nope")
            {
                this.lblResult.ForeColor = Color.Red;
                this.lblResult.Text = "Ce médicament n'est pas disponible.";
                this.btnBuy.Enabled = false;
            }
     
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
