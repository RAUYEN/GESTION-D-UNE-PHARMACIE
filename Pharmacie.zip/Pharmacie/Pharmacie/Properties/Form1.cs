﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Pharmacie
{
    public partial class Form1 : Form
    {
        

        public List<String> getNomPharma()
        {

            List<String> nomPharma = new List<String>();
            nomPharma.Add("Borj louzir aiana");
            nomPharma.Add("sokra aiana");
            nomPharma.Add("manealkjl aiana");
            nomPharma.Add("waywayye aiana");
            nomPharma.Add("sdlkfjsldkfjl aiana");

            return nomPharma;
        }
        public void cnx_db()
        {
            OleDbConnection con = new OleDbConnection();
            con.ConnectionString = System.Configuration.ConfigurationManager.ConnectionStrings["cnx"].ToString();
            MessageBox.Show(con.ConnectionString);
            con.Open();
            //-MessageBox.Show("zebi");
        }

        public void btnPharmaClick(Button sender, System.EventArgs e)
        {
            MessageBox.Show(sender.Text);
        }
        public void ajouterPharmacie()
        {
            List < String > nomPharmacie = getNomPharma();
            foreach (String nomPharma in nomPharmacie)
            {
                Button btn = new Button();
                btn.Text = nomPharma;
                btn.Height += 50;
                btn.Width += 50;
                btn.TextAlign = ContentAlignment.MiddleCenter;
                btn.Click += (s, e) => {
                    Pharmacie.Properties.pharmaSearch f2 = new Properties.pharmaSearch();
                    f2.Text = btn.Text;
                    f2.ShowDialog();
                };
                this.container.Controls.Add(btn);
                
            }

            
           
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //cnx_db();
            ajouterPharmacie();
        }

        private void tbSearch_TextChanged(object sender, EventArgs e)
        {
            if (tbSearch.Text == "admin")
            {
                tbSearch.Text = "";
                Pharmacie.Properties.Admin admin = new Properties.Admin();
                admin.Show();
                //this.Hide();
            }
            List<String> nomPharmacie = getNomPharma();
            this.container.Controls.Clear();
            foreach (String nomPharma in nomPharmacie)
            {
                if (nomPharma.ToLower().Contains(tbSearch.Text.ToLower()))
                {
                    Button btn = new Button();
                    btn.Text = nomPharma;
                    btn.Height += 50;
                    btn.Width += 50;
                    btn.TextAlign = ContentAlignment.MiddleCenter;
                    btn.Click += (s, x) => {
                        Pharmacie.Properties.pharmaSearch f2 = new Properties.pharmaSearch();
                        f2.Text = btn.Text;
                        f2.ShowDialog();
                    };
                    this.container.Controls.Add(btn);

                }
                

            }

        }
    }
}
