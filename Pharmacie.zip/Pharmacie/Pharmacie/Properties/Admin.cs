﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pharmacie.Properties
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (tbUser.Text == "admin")
                if (tbPass.Text == "admin")
                {
                    Properties.AdminCRUD adminCrud = new Properties.AdminCRUD();
                    adminCrud.Show();
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Nom d'utilisateur ou mot de passe incorrecte.");
                }
        }

        private void Admin_Load(object sender, EventArgs e)
        {
            tbUser.Focus();
        }
    }
}
